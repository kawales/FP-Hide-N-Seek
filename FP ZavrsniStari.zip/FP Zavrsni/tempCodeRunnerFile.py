           if(self.currentSpr>len(self.sprites)-1):
                    self.currentSpr=0
            elif(self.currentSpr<0):
                    self.currentSpr=len(self.sprites)-1